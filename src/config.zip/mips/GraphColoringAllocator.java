package mips;

import llvmir.value.Value;
import llvmir.value.instructions.*;
import llvmir.value.structure.BasicBlock;
import llvmir.value.structure.Function;
import llvmir.value.structure.Instruction;
import llvmir.value.structure.Module;
import llvmir.value.structure.Param;
import mips.structure.MipsFunc;
import mips.value.MipsOperand;
import mips.value.PhyReg;
import mips.value.StackSlot;

import java.util.*;

public class GraphColoringAllocator {
    private final LivenessAnalyzer livenessAnalyzer;
    private final GenerationContext context;
    
    private Map<Value, Set<Value>> adjList = new HashMap<>();
    private Map<Value, Integer> degree = new HashMap<>();
    private Set<Value> nodes = new HashSet<>(); // Only non-precolored nodes to be colored
    private Stack<Value> selectStack = new Stack<>();
    private Set<Value> spilledNodes = new HashSet<>();
    
    // K = 18: $t0-$t9 (10) + $s0-$s7 (8)
    private static final int K = 18;
    private List<PhyReg> allocatableRegs = new ArrayList<>();

    public GraphColoringAllocator(GenerationContext context) {
        this.context = context;
        this.livenessAnalyzer = new LivenessAnalyzer();
        initializeRegs();
    }

    private void initializeRegs() {
        // $t0-$t9
        allocatableRegs.add(PhyReg.T0); allocatableRegs.add(PhyReg.T1);
        allocatableRegs.add(PhyReg.T2); allocatableRegs.add(PhyReg.T3);
        allocatableRegs.add(PhyReg.T4); allocatableRegs.add(PhyReg.T5);
        allocatableRegs.add(PhyReg.T6); allocatableRegs.add(PhyReg.T7);
        allocatableRegs.add(PhyReg.T8); allocatableRegs.add(PhyReg.T9);
        // $s0-$s7
        allocatableRegs.add(PhyReg.S0); allocatableRegs.add(PhyReg.S1);
        allocatableRegs.add(PhyReg.S2); allocatableRegs.add(PhyReg.S3);
        allocatableRegs.add(PhyReg.S4); allocatableRegs.add(PhyReg.S5);
        allocatableRegs.add(PhyReg.S6); allocatableRegs.add(PhyReg.S7);
    }

    public void allocateRegisters(Module module) {
        livenessAnalyzer.analyze(module);
        
        for (Value function : module.getFunctions()) {
            allocateForFunction((Function) function);
        }
        allocateForFunction(module.getMainFunction());
    }

    private void allocateForFunction(Function function) {
        String funcName = function.getName().substring(1);
        MipsFunc mipsFunc = context.getMipsModule().getFunction(funcName);
        if (funcName.equals("main")) mipsFunc = context.getMipsModule().main;
        
        // Reset state
        adjList.clear();
        degree.clear();
        nodes.clear();
        selectStack.clear();
        spilledNodes.clear();
        
        buildGraph(function);
        simplifyAndSpill();
        assignColors(mipsFunc);
    }

    private void buildGraph(Function function) {
        // 1. Identify nodes (Instructions that produce values)
        for (BasicBlock bb : function.getBasicBlocks()) {
            for (Instruction inst : bb.getInstructions()) {
                if (inst.getType() != null && !inst.getType().isVoidType()) {
                    // Exclude Alloca instructions from coloring
                    if (!(inst instanceof Alloca)) {
                        nodes.add(inst);
                        adjList.put(inst, new HashSet<>());
                        degree.put(inst, 0);
                    }
                }
            }
        }
        // Params are pre-colored or stack-allocated. 
        // If they are in registers ($a0-$a3), they are pre-colored.
        // If they are on stack, they are not involved in coloring (already assigned).
        // But we need to track them for interference if they are used.
        
        // 2. Build edges based on liveness
        for (BasicBlock bb : function.getBasicBlocks()) {
            Set<Value> live = new HashSet<>(livenessAnalyzer.getOut(bb));
            
            List<Instruction> insts = bb.getInstructions();
            for (int i = insts.size() - 1; i >= 0; i--) {
                Instruction inst = insts.get(i);
                
                if (inst.getType() != null && !inst.getType().isVoidType()) {
                    if (!(inst instanceof Alloca)) {
                        // Def interferes with LiveOut
                        for (Value liveVar : live) {
                            if (liveVar != inst) {
                                addEdge(inst, liveVar);
                            }
                        }
                        // Def is not live before definition
                        live.remove(inst);
                    }
                }
                
                // Uses become live
                for (Value operand : inst.getOperands()) {
                    if (operand instanceof Instruction || operand instanceof Param) {
                        live.add(operand);
                    }
                }
            }
        }
    }

    private void addEdge(Value u, Value v) {
        // We only care about edges connected to nodes we want to color.
        // u and v can be: Instruction (node), Param (pre-colored or stack), or other Value.
        
        boolean uIsNode = nodes.contains(u);
        boolean vIsNode = nodes.contains(v);
        
        if (uIsNode && vIsNode) {
            if (!adjList.get(u).contains(v)) {
                adjList.get(u).add(v);
                adjList.get(v).add(u);
                degree.put(u, degree.get(u) + 1);
                degree.put(v, degree.get(v) + 1);
            }
        } else if (uIsNode && isPreColored(v)) {
            // u interferes with pre-colored v
            if (!adjList.get(u).contains(v)) {
                adjList.get(u).add(v);
                degree.put(u, degree.get(u) + 1); // Optional: increasing degree for pre-colored interference
            }
        } else if (vIsNode && isPreColored(u)) {
            if (!adjList.get(v).contains(u)) {
                adjList.get(v).add(u);
                degree.put(v, degree.get(v) + 1);
            }
        }
    }
    
    private boolean isPreColored(Value v) {
        return v.getRegister() instanceof PhyReg;
    }

    private void simplifyAndSpill() {
        // Working set of nodes to simplify
        Set<Value> activeNodes = new HashSet<>(nodes);
        
        while (!activeNodes.isEmpty()) {
            // Simplify: find node with degree < K
            Value nodeToSimplify = null;
            for (Value node : activeNodes) {
                if (degree.get(node) < K) {
                    nodeToSimplify = node;
                    break;
                }
            }
            
            if (nodeToSimplify != null) {
                selectStack.push(nodeToSimplify);
                activeNodes.remove(nodeToSimplify);
                removeNode(nodeToSimplify, activeNodes);
            } else {
                // Spill: pick node with max degree
                Value nodeToSpill = null;
                int maxDegree = -1;
                for (Value node : activeNodes) {
                    if (degree.get(node) > maxDegree) {
                        maxDegree = degree.get(node);
                        nodeToSpill = node;
                    }
                }
                
                if (nodeToSpill != null) {
                    // Optimistic coloring: push to stack anyway
                    selectStack.push(nodeToSpill);
                    activeNodes.remove(nodeToSpill);
                    removeNode(nodeToSpill, activeNodes);
                }
            }
        }
    }

    private void removeNode(Value node, Set<Value> activeNodes) {
        for (Value neighbor : adjList.get(node)) {
            if (activeNodes.contains(neighbor)) {
                degree.put(neighbor, degree.get(neighbor) - 1);
            }
        }
    }

    private void assignColors(MipsFunc mipsFunc) {
        while (!selectStack.isEmpty()) {
            Value node = selectStack.pop();
            Set<PhyReg> usedColors = new HashSet<>();
            
            for (Value neighbor : adjList.get(node)) {
                // Check neighbors
                // Neighbor could be:
                // 1. Pre-colored (Param)
                // 2. Already colored node (popped before this one)
                // 3. Uncolored node (still in stack? No, we process in reverse pop order)
                //    Wait, if neighbor is in stack, it's not colored yet.
                //    If neighbor was popped BEFORE this node, it is colored.
                
                MipsOperand reg = neighbor.getRegister();
                if (reg instanceof PhyReg) {
                    usedColors.add((PhyReg) reg);
                }
            }
            
            PhyReg assigned = null;
            for (PhyReg reg : allocatableRegs) {
                if (!usedColors.contains(reg)) {
                    assigned = reg;
                    break;
                }
            }
            
            if (assigned != null) {
                node.setRegister(assigned);
            } else {
                // Actual spill
                spilledNodes.add(node);
                int offset = mipsFunc.getStackSize();
                node.setRegister(new StackSlot(offset));
                mipsFunc.setStackSize(offset + 4);
            }
        }
    }
}
