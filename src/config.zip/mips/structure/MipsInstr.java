package mips.structure;

public class MipsInstr {
    public MipsInstr(){}
}
