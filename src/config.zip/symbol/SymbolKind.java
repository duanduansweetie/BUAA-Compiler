package symbol;

public enum SymbolKind {
    VARIABLE, CONSTANT,STATIC
}
