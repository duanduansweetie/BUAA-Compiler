package symbol;

public enum SymbolType {
    INT,VOID;
}
