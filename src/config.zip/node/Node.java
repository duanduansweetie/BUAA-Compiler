package node;
//语法树基类
public abstract class Node {
    public Node(){
    }
    public abstract void show() throws Exception;
}
