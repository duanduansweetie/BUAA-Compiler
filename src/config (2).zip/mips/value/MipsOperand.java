package mips.value;

public interface MipsOperand {
    String toString();
}
